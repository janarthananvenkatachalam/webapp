module.exports = {
 MongoURI: 'mongodb+srv://vjaansens:qwerty123@cluster1-6nyff.mongodb.net/test?retryWrites=true&w=majority'   
} 